"""
Core
====

Core *maize* functionality.

"""
